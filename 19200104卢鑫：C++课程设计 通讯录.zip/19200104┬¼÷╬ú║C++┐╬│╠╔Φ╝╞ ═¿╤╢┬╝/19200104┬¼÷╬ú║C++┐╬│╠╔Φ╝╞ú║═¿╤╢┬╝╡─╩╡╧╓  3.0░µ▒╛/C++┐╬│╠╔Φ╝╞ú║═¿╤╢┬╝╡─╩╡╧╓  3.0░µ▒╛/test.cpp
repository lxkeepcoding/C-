#define _CRT_SECURE_NO_WARNINGS   1


#include "PeoInfo.h"
#include "List.h"
#include"user.h"
#include <stdlib.h>
#include <iostream>
using namespace std;



int main()
{
	User me;
	me.choice();
	system("pause");
	return 0;
}