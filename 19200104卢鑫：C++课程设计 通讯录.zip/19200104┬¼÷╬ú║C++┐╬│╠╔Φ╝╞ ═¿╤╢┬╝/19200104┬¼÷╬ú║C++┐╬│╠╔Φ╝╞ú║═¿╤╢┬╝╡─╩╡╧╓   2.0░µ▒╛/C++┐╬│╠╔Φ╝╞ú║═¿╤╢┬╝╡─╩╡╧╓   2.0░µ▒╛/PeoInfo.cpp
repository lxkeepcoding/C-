#define _CRT_SECURE_NO_WARNINGS   1

#include "PeoInfo.h"

PeoInfo::PeoInfo()
{
}

PeoInfo::~PeoInfo()
{
}

