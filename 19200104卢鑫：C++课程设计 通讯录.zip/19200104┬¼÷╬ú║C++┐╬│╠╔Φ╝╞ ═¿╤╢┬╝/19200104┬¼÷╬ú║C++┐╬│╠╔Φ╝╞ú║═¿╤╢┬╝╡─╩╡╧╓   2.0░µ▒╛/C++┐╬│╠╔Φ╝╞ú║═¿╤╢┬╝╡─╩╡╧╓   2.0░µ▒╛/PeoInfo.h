#ifndef PEOINFO_H_
#define PEOINFO_H_

#include<iostream>
#include <string>
using namespace std;

class PeoInfo
{
public:
	string _name;
	string _department;
	string _class;
	string _telephone;
	string _email;
	string _address;
	string _postcode;
public:
	PeoInfo();
	~PeoInfo();
private:

};


#endif 

